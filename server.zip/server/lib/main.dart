import 'dart:convert';
import 'dart:io';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;
import 'package:shelf_router/shelf_router.dart';

// کلاس مدیریت لینک
class Link {
  String url;
  int score;

  Link(this.url, {this.score = 0});
}

// سیستم توصیه‌گر
class RecommenderSystem {
  Map<String, List<String>> userWords = {
    "user1": ["animation", "kungfu panda", "movies"],
    "user2": ["kids", "merchandise", "action figures"],
    "user3": ["kung fu", "martial arts", "adventure"],
  };

  Map<String, List<String>> wordLinks = {
    "animation": [
      "https://www.aparat.com/v/vUt7W", // انیمیشن کنگ‌فو پاندا
      "https://www.filimo.com/series/27651/همه-چیز-درباره-انیمیشن" // اطلاعات انیمیشن
    ],
    "kungfu panda": [
      "https://www.bamilo.com/catalogsearch/result/?q=کنگ+فو+پاندا", // محصولات کنگ‌فو پاندا
      "https://www.digikala.com/search/category-toys-and-games-0/?q=کنگ+فو+پاندا" // اسباب‌بازی‌های کنگ‌فو پاندا
    ],
    "movies": [
      "https://www.filimo.com/movies/1877/انیمیشن-کنگ-فو-پاندا-3", // کنگ‌فو پاندا ۳
      "https://www.aparat.com/v/g39hK" // لیست انیمیشن‌های خانواده
    ],
    "kids": [
      "https://www.filimo.com/series/32932/انیمیشن-برای-کودکان", // انیمیشن‌های کودکان
      "https://www.bamilo.com/catalogsearch/result/?q=اسباب+بازی+کودکان" // اسباب‌بازی‌های کودکان
    ],
    "merchandise": [
      "https://www.kala.ir/search?q=کنگ+فو+پاندا", // کالای مرتبط با کنگ‌فو پاندا
      "https://www.digikala.com/search/category-toys-and-games-0/?q=مرچندایز" // مرچندایز فیلم‌ها
    ],
    "action figures": [
      "https://www.digikala.com/search/category-toys-and-games-0/?q=اکشن+فیگور", // اکشن فیگورها
      "https://www.bamilo.com/catalogsearch/result/?q=اکشن+فیگور+کنگ+فو+پاندا" // اکشن فیگورهای کنگ‌فو پاندا
    ],
    "kung fu": [
      "https://www.kungfu.ir/" // وب‌سایت‌های کنگ‌فو
          "https://www.filimo.com/tags/کنگ-فو/" // فیلم‌های کنگ‌فو
    ],
    "martial arts": [
      "https://www.karate.ir/" // وب‌سایت‌های هنرهای رزمی
          "https://www.aparat.com/v/jItqN" // ویدیوهای هنرهای رزمی
    ],
    "adventure": [
      "https://www.filimo.com/movies/13947/فیلم-ماجراجویی", // فیلم‌های ماجراجویی
      "https://www.aparat.com/v/0qH4H" // انیمیشن‌های ماجراجویی
    ],
  };


  Map<String, int> linkClicks = {};

  Map<String, int> wordWeights = {
    "kungfu panda": 3,
    "animation": 2,
    "movies": 2,
    "kids": 1,
    "merchandise": 1,
    "action figures": 2,
    "kung fu": 1,
    "martial arts": 1,
    "adventure": 1,
  };

  Future<String> getRecommendationLink(String user, List<String> inputWords) async {
    Map<String, Link> linkScores = {};

    for (var word in inputWords) {
      var links = wordLinks[word] ?? [];
      for (var link in links) {
        int weight = wordWeights[word] ?? 1;
        linkScores.putIfAbsent(link, () => Link(link));

        // امتیازدهی با توجه به وزن کلمات و تعداد کلیک‌ها
        linkScores[link]!.score += weight + (linkClicks[link] ?? 0);
      }
    }

    // پیدا کردن لینک با بیشترین امتیاز
    if (linkScores.isNotEmpty) {
      return linkScores.values.reduce((a, b) => a.score > b.score ? a : b).url;
    } else {
      return "No recommendation available";
    }
  }

  void registerClick(String link) {
    linkClicks[link] = (linkClicks[link] ?? 0) + 1;
  }

  void registerMiss(String link) {
    linkClicks[link] = (linkClicks[link] ?? 0) - 1;
    if (linkClicks[link]! <= 0) {
      linkClicks.remove(link);
    }
  }
}

final recommenderSystem = RecommenderSystem();

Router createRouter() {
  final router = Router();

  router.post('/recommend', (Request request) async {
    var body = await request.readAsString();
    var data = jsonDecode(body);
    var user = data['user'];
    var words = List<String>.from(data['words']);

    var recommendedLink = await recommenderSystem.getRecommendationLink(user, words);
    return Response.ok(jsonEncode({'recommendedLink': recommendedLink}), headers: {'Content-Type': 'application/json'});
  });

  router.post('/track', (Request request) async {
    var body = await request.readAsString();
    var data = jsonDecode(body);
    var link = data['link'];
    var clicked = data['clicked'];

    if (clicked) {
      recommenderSystem.registerClick(link);
    } else {
      recommenderSystem.registerMiss(link);
    }

    return Response.ok(jsonEncode({'status': 'success'}), headers: {'Content-Type': 'application/json'});
  });

  return router;
}

void main() async {
  var handler = const Pipeline().addMiddleware(logRequests()).addHandler(createRouter());
  var server = await io.serve(handler, '0.0.0.0', 8080);
  print('Server running on localhost:${server.port}');
}
